import speech_recognition as sr
import openai
from config import apikey
import win32com.client as wincl 
import numpy as np
import random
import time
from playsound import playsound
import os,psutil
import signal
import datetime
import pywhatkit
import wolframalpha
import keyboard
import pc_controls
from pollytest import say
import datetime
import calendar
import wikipedia
import pyautogui
import error
import success 
from email.message import EmailMessage
import smtplib
#from decouple import config
import imdb
import gemini
import weather
import ai_image
import news
import pdf 
import socket
import systeminfo
import clearbin
import storageinfo
import winshell 
import subprocess
import notes
import whatsa2
import welcome

EMAIL = ""
PASSWORD = ""


TRIGGER_WORDS = ["answer engine", "wolfram", "ask wolfram"]

def get_wolframalpha_answer(query):
    app_id = "3RKKRW-WUXV63VETG"

    client = wolframalpha.Client(app_id)
    try:
        result = client.query(query)
        answer = next(result.results).text
        return answer
    except StopIteration:
        return "Sorry, I couldn't find an answer for that."
    except Exception as e:
        print(f"Error occurred: {e}")
        return "An error occurred. Please try again later."
def is_wolframalpha_query(query):
    for word in TRIGGER_WORDS:
        if query is not None and word in query:
            return True
    return False

def send_email(receiver_add, subject, message):
    try:
        email = EmailMessage()
        email['To'] = receiver_add
        email['Subject'] = subject
        email['From'] = "fiazmohammad389@gmail.com"  

        email.set_content(message)

        with smtplib.SMTP("smtp.gmail.com", 587) as s:     
            s.ehlo()  
            s.starttls() 
            s.ehlo()  
            s.login("fiazmohammad389@gmail.com", "qhxa ayuq mqbm jcgd") 
            s.send_message(email)
            s.set_debuglevel(True)
        return True

    except smtplib.SMTPAuthenticationError as e:
        print("Authentication Error:", e)
        return False
    except Exception as e:
        print("General Error:", e)
        return False

def chat(query):
    
   
    
    openai.api_key = apikey
    response = openai.Completion.create(
        model="gpt-3.5-turbo-instruct",
        prompt=query,
        temperature=0.7,
        max_tokens=100,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )
    try:
        answer = response["choices"][0]["text"]
        say(answer)
        return answer
    except Exception as e:
        
        say("Sorry, GPT is having trouble understanding you right now. Please try again later.")


def today_date():
    now = datetime.datetime.now()
    date_now = datetime.datetime.today()
    week_now = calendar.day_name[date_now.weekday()]
    month_now = now.month
    day_now = now.day
    

    months = ["January","February","March","April","May","June","July","August","September","October","November","December"]

    ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st",
        "22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"]

    return "Today is " + week_now + ", " + months[month_now - 1] + "," + ordinals[day_now - 1] + "."


def listen(threshold=9000):
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)
        r.energy_threshold = threshold
        audio = r.listen(source)
        try:
            query = r.recognize_google(audio, language="en-in").lower()
            return query
        except Exception as e:
            
            pass  

'''def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)  
        audio_data = r.listen(source)

        try:
            
            audio_data, sample_rate = librosa.load(audio_data, res_type="kaiser_fast") 

            audio_for_sr = librosa.output.write_wav(audio_data, sample_rate)  

            query = r.recognize_google(audio_for_sr, language="en-in").lower()
            return query
        except Exception as e:
            pass''' 

def main():
    welcome.play_welcome()
    greetings=["Hello","Hi","Hello, Fiaz","Greetings","Howdy!","What a pleasant surprise!","Namaste","Hey mate!"]
    say(random.choice(greetings))
    while True:
        trigger=listen()
        if trigger is not None and "wake up" in trigger:
            success.play_success()
            say("listening")
            
    
            while True:
        
                start_time = time.time()
                query = listen()

                if query is not None and "the time" in query:
                    hour=datetime.datetime.now().strftime("%H")
                    minute=datetime.datetime.now().strftime("%M")
                    success.play_success()
                    say(f"The time is {hour} hours {minute} minutes")
                    break
                elif query is not None and "date" in query:
                    t=today_date()
                    success.play_success()
                    say(t)
                    break
                elif query is not None and "wikipedia" in query:
                    say('Searching Wikipedia...')
                    query = query.replace("wikipedia", "")
                    results = wikipedia.summary(query, sentences=2)
                    success.play_success()
                    say("According to Wikipedia")
                    #print(results)
                    say(results)
                    break
                

                elif is_wolframalpha_query(query):  
                    answer = get_wolframalpha_answer(query)
                    success.play_success()
                    say(answer)
                    break

                elif query is not None and "switch to non visual desktop access" in query:
                    success.play_success()
                    say("Opening non visual desktop access")
                    nvda_path="C:\\Program Files (x86)\\NVDA\\nvda_noUIAccess.exe"
                    os.startfile(nvda_path)
                    break
                    
                elif query is not None and  "close non visual desktop access" in query:
                    success.play_success()
                    say("Closing non visual desktop access")
                    for pid in (process.pid for process in psutil.process_iter() if process.name()=="nvda_noUIAccess.exe"):
                        os.kill(pid, signal.SIGTERM)
                    break
                elif query is not None and "open google chrome" in query:
                    success.play_success()
                    say("Opening google chrome")
                    chrome_path="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
                    os.startfile(chrome_path)
                    break
                elif query is not None and "open brave browser" in query:
                    success.play_success()
                    say("Opening brave browser")
                    brave_path="C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
                    os.startfile(brave_path)
                    break
                elif query is not None and "open driver booster" in query:
                    success.play_success()
                    say("opening driver booster")
                    driver_path="C:\\Program Files (x86)\\IObit\\Driver Booster\\11.1.0\\DriverBooster.exe"
                    os.startfile(driver_path)
                    break
                elif query is not None and "open microsoft edge" in query:
                    success.play_success()
                    say("opening microsoft edge")
                    edge_path="C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
                    os.startfile(edge_path)
                    break
                elif query is not None and "open command prompt" in query:
                    success.play_success()
                    say("opening command prompt")
                    os.system("start cmd")
                    break
                elif query is not None and "open notepad" in query:
                    success.play_success()
                    say("opening notepad")
                    os.system("notepad.exe")
                    break
                elif query is not None and "take screenshot" in query:
                    success.play_success()
                    say('tell me a name for the file')
                    name = listen().lower()
                    time.sleep(2)
                    img = pyautogui.screenshot() 
                    img.save(f"{name}.png") 
                    say("screenshot saved")
                    break
            
                elif query is not None and "open downloads folder" in query:

                    success.play_success()   
                    say("opening downloads folder")
                    downloads_folder = os.path.expanduser("~/Downloads")
                    os.startfile(downloads_folder)
                    break

                elif query is not None and "open file explorer" in query:
                    success.play_success()
                    say("opening file explorer")
                    subprocess.Popen('explorer')
                    break
                
                elif query is not None and "open settings" in query:
                    success.play_success() 
                    say("opening settings")
                    pyautogui.hotkey('win', 'i')
                    break
                  
                elif query is not None and "open control panel" in query:
                    success.play_success()
                    say("opening control panel")
                    os.startfile('control')
                    break

                elif query is not None and  "shutdown the system" in query:
                    success.play_success()
                    say("sure")
                    pc_controls.shutdown_system(2)
                    break
                elif query is not None and "restart the system" in query:
                    success.play_success()
                    say("sure")
                    pc_controls.restart_system(2)
                    break
                elif query is not None and "lock screen" in query:
                    success.play_success()
                    say("sure")
                    pc_controls.lock_screen()
                    break
                elif query is not None and "search on google" in query.lower():
                    query = query.lower().replace("search on google ", "")
                    pywhatkit.search(query)
                    success.play_success()
                    say("Searching on Google for: " + query)
                    break
                elif query is not None and "search on youtube" in query.lower():
                    query = query.lower().replace("search on youtube ", "")
                    pywhatkit.playonyt(query)
                    success.play_success()
                    say("Searching on YouTube for: " + query)
                    break 
                elif query is not None and "send an email" in query.lower():
                    success.play_success()
                    '''say("On what email address do you want to send sir?. Please enter in the terminal")
                    receiver_add = input("Email address:")
                    say("What should be the subject sir?")
                    subject = listen()
                    say("What is the message ?")
                    message = listen()
                    if send_email(receiver_add, subject, message):
                        say("I have sent the email sir")
                    
                    else:
                        say("something went wrong")
                    break'''

                    contacts = {
                        "contact number 1": "fiazmohammad2002@gmail.com",
                        "contact number 2": "krishnangokul2218@gmail.com",
                        "contact number 3": "benitasusan457422@gmail.com",
                        "contact number 4": "donalisamathew@gmail.com"
                        
                    }
                    say("Which contact would you like to send the email to?")
                    
                    contact_name = listen()
                    while contact_name not in contacts:
                        say("Invalid contact name. Please try again.")
                        contact_name = listen()

                    receiver_add = contacts[contact_name]
                    say("What should be the subject sir?")
                    subject = listen()
                    say("What is the message?")
                    message = listen()
                    if send_email(receiver_add, subject, message):
                        say("I have sent the email sir")
                    else:
                        say("Something went wrong")

                    break

                elif query is not None and "generate an image of" in query: 
                    image_query = query.replace("generate an image of", "").strip() 
                    imageUrl = ai_image.generate_image(image_query)
                    ai_image.display_image(imageUrl)
                    break

                elif query is not None and "notes maker" in query:
                    success.play_success()
                    notes.main_notes()
                    break



                elif query is not None and "movie" in query:
                    movies_db = imdb.IMDb()
                    success.play_success()
                    say("Please tell me the movie name:")
                    text = listen()
                    movies = movies_db.search_movie(text)
                    say("searching for" + text)
                    
                    for movie in movies:
                        title = movie["title"]
                        year = movie["year"]
                        
                        info = movie.getID()
                        movie_info = movies_db.get_movie(info)
                        rating = movie_info.get('rating', 'rating not available')
                        cast = movie_info["cast"]
                        actor_names = [person.get('name', 'name not available') for person in cast[0:3]]  # Use 'cast' here
                        actor_list = ", ".join(actor_names) 
                        plot = movie_info.get('plot outline', 'plot summary not available')
                    
                        try :

                            say(f"{title} was released in {year} has imdb ratings of {rating}.\n It has a cast of {actor_list}. \n"
                            f"The plot summary of movie is {plot}")
                        except Exception as e:
                            print("Some error occurred. Please try again later.")
                        break
                    break    
                elif query is not None and "volume up" in query:
                    pyautogui.press("volumeup")
                    pyautogui.press("volumeup")
                    pyautogui.press("volumeup")
                    pyautogui.press("volumeup")
                    pyautogui.press("volumeup")
                    success.play_success()
                    say("volume increased by 10 percent")
                    break
                elif query is not None and "volume down" in query:
                    pyautogui.press("volumedown")
                    pyautogui.press("volumedown")
                    pyautogui.press("volumedown")
                    pyautogui.press("volumedown")
                    pyautogui.press("volumedown")
                    success.play_success()
                    say("volume decreased by ten percent")
                    break
                elif query is not None and "mute" in query:
                    pyautogui.press("volumemute")
                    break
                elif query is not None and "unmute" in query:
                    pyautgui.press("volumeup")
                    say("unmuted")
                    break
                elif query is not None and "google" in query:
                    success.play_success()
                    say('Using Google Gemini')
                    prompt = query.replace("google", "")
                    say(gemini.query_gemini(prompt))
                    break

                elif query is not None and "gpt" in query:  
                    query = query.replace("chatgpt", "").strip()
                    success.play_success()
                    say("using chat gpt 3.5")
                    chat(query)
                    break

                elif query is not None and "send message" in query:
                    whatsa2.sendMessage()
                    break            
                elif query is not None and "weather" in query:
                    success.play_success()
                    weather.weather_main()
                    break
                elif query is not None and "click my photo" in query:
                    pyautogui.press('win')
                    pyautogui.typewrite('camera')
                    pyautogui.press('enter')

                    time.sleep(5)
                    success.play_success()

                    say("Say cheese!")
    
                    pyautogui.press('enter')
    
                    time.sleep(4)
    
                    pyautogui.press('enter')
                    say("photo saved in gallery")
                    break
                elif query is not None and "read news" in query:
                    success.play_success()
                    say("I am reading out the latest news headlines")
                    news_headline = news.get_news()
                    news.read_news(news_headline)
                    break
                elif query is not None and "read pdf" in query:
                    success.play_success()
                    pdf.read_pdf()  
                    break 
                elif query is not None and "ip address" in query:
                    hostname = socket.gethostname()
                    IPAddr = socket.gethostbyname(hostname)
                    success.play_success()
                    #say("Your Computer Name is" + hostname)
                    say("Your Computer IP Address is" + IPAddr)
                    break
                elif query is not None and "system information" in query:
                    success.play_success()
                    systeminfo.get_system_info()
                    break
                elif query is not None and "storage information" in query:
                    success.play_success()
                    storageinfo.get_disk_usage()
                    break
                elif query is not None and "clear recycle bin" in query:
                    success.play_success()
                    clearbin.clear_recycle_bin()
                    break
                elif query is not None and "standby" in query:
                    success.play_success()
                    say("Returning to standby.")
                    break
                elif time.time() - start_time > 10:
                    error.play_error() 
                    say("No command detected. Returning to standby.")
                    break
                else: 
                    error.play_error()   
                    say("Undefined command or noise detected")
                    break
        elif trigger in ["quit", "exit", "Bye"]:

                
            say("Bye! Have a nice day")
            #pyautogui.hotkey('ctrl', 'w')
            break 
         
        else:
            print("No wake word detected")
        

if __name__ == "__main__":
    main()