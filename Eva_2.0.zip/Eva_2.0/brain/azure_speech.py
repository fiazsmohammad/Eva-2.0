import azure.cognitiveservices.speech as speechsdk

# Replace with your Azure Speech Services subscription key and service region
speech_key, service_region = "22d885c5ac74430583e84d61c21b2a82", "eastus"

def start_continuous_recognition(speech_key, service_region):
    """Starts continuous speech recognition with event handling."""

    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)

    print("Say something...")

    def handle_recognized(evt):
        print("Recognized: {}".format(evt.result.text))

    def handle_canceled(evt):
        cancellation_details = evt.cancellation_details
        print("Speech Recognition canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("Error details: {}".format(cancellation_details.error_details))

    speech_recognizer.recognized.connect(handle_recognized)
    speech_recognizer.canceled.connect(handle_canceled)

    speech_recognizer.start_continuous_recognition()

    while True:  # Keep the program running until user input to stop
        pass

