import os
import speech_recognition as sr
from dotenv import load_dotenv
from boto3 import Session
from botocore.exceptions import BotoCoreError, ClientError
import pygame
from io import BytesIO


load_dotenv()


access_key_id = os.environ.get('AWS_ACCESS_KEY_ID')
secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
region_name = os.environ.get('AWS_DEFAULT_REGION')

def say(text):
    
    if not isinstance(text, str):
        raise ValueError("Text must be a string.")

    if not text:
        raise ValueError("Text cannot be empty.")

    if len(text) > 1500:
        raise ValueError("Text too long. Maximum 1500 characters supported.")

    try:
        
        os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = 'hide'
        os.environ['SDL_VIDEODRIVER'] = 'dummy'
        pygame.init()
        polly_client = Session(aws_access_key_id=access_key_id,
                                aws_secret_access_key=secret_access_key,
                                region_name=region_name).client('polly')

        
        response = polly_client.synthesize_speech(
            VoiceId='Amy',
            OutputFormat='mp3',
            Text=text
        )
        #pygame.mixer.music.set_volume(1)

        
        pygame.mixer.init()

        
        pygame.mixer.music.load(BytesIO(response['AudioStream'].read()))

        
        pygame.mixer.music.play()

        
        while pygame.mixer.music.get_busy():
            continue

    except (ValueError, BotoCoreError, ClientError) as e:
        print(f"Error synthesizing text: {e}")
    except sr.UnknownValueError:
        print("Speech recognition could not understand audio.")
    return "Audio playback completed"
#say("hi there, i am eva your virtual assistant. how may i assist you today ?")

