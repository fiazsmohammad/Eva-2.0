import psutil
from pollytest import say

def get_disk_usage():
    partitions = psutil.disk_partitions()

    for partition in partitions:
        device = partition.device
        mount_point = partition.mountpoint
        file_system_type = partition.fstype
        try:
            partition_usage = psutil.disk_usage(mount_point)
        except PermissionError:
            
            continue

        total_size = partition_usage.total >> 30  
        used_size = partition_usage.used >> 30
        free_size = partition_usage.free >> 30
        percent_used = partition_usage.percent

        
        say(f"Mount Point: {mount_point}")
        say(f"File System: {file_system_type}")
        say(f"Total Size: {total_size} GB")
        say(f"Used Size: {used_size} GB")
        say(f"Free Size: {free_size} GB")
        say(f"Percent Used: {percent_used}%")
        


