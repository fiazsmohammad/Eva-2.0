import subprocess
import os
import ctypes

  
def shutdown_system(time_delay):

    os.system(f"shutdown /s /t {time_delay}")
def restart_system(time_delay):
    
    os.system(f"shutdown /r /t {time_delay}")
def lock_screen():
    ctypes.windll.user32.LockWorkStation()
