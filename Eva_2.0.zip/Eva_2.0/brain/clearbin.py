import winshell
from pollytest import say

def clear_recycle_bin():
    try:
        winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=False)
        say("Recycle Bin cleared successfully.")
    except:
        say("Recycle bin is empty")


