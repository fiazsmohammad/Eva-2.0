import pywhatkit
import time
import speech_recognition as sr
from pollytest import say 
import pyautogui

def listen_w():
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            query = r.recognize_google(audio, language="en-in").lower()
            return query
        except Exception as e:
            
            pass
def sendMessage():
    
    try :
        say("Who do you want to message?")
        a=listen_w()
        if a=="contact number 1": #fiaz
            say("what is the message?")
            message=listen_w()
            phone_number = "+916374858097"
            pywhatkit.sendwhatmsg_instantly(phone_number, message)
            time.sleep(1)
            pyautogui.click(x=1844, y=952)
            time.sleep(2)
            pyautogui.hotkey('ctrl', 'w')
            time.sleep(1)
            #pyautogui.click(x=1891, y=18)
            say("your message has been delivered")
            


        elif a=="contact number 2": #gokul
            say("what is the message?")
            message=listen_w()
            phone_number = "+919895485202"
            pywhatkit.sendwhatmsg_instantly(phone_number, message)
            time.sleep(1)
            pyautogui.click(x=1844, y=952)
            time.sleep(2)
            pyautogui.hotkey('ctrl', 'w')
            time.sleep(1)
            #pyautogui.click(x=1891, y=18)
            say("your message has been delivered")
            
        elif a=="contact number 3": #benita
            say("what is the message?")
            message=listen_w()
            phone_number = "+919656408945"
            pywhatkit.sendwhatmsg_instantly(phone_number, message)
            time.sleep(1)
            pyautogui.click(x=1844, y=952)
            time.sleep(2)
            pyautogui.hotkey('ctrl', 'w')
            time.sleep(1)
            #pyautogui.click(x=1891, y=18)
            say("your message has been delivered")

        elif a=="contact number 4": #dona
            say("what is the message?")
            message=listen_w()
            phone_number = "+919656384335"
            pywhatkit.sendwhatmsg_instantly(phone_number, message)
            time.sleep(1)
            pyautogui.click(x=1844, y=952)
            time.sleep(2)
            pyautogui.hotkey('ctrl', 'w')
            time.sleep(1)
            #pyautogui.click(x=1891, y=18)
            say("your message has been delivered")
            
        else :
            say("contact not found")
        
            
    except Exception as e:
        say("Some error occurred. Please try again later.")
        



