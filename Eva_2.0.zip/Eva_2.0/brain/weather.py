import speech_recognition as sr
import requests
import json
from pollytest import say


def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        say("Please say the name of the city:")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        city = recognizer.recognize_google(audio)
        say(f"You said{city}")
        return city
    except sr.UnknownValueError:
        say("Sorry, I could not understand your audio.")
        return None
    except sr.RequestError as e:
        say("Could not request results; {0}".format(e))
        return None


def get_weather(city):
    api_key = "b17731853e95a7977916d88f0a43ba70"
    
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    complete_url = f"{base_url}q={city}&appid={api_key}&units=metric"
    response = requests.get(complete_url)
    data = response.json()
    

    if data["cod"] != "404":
        try:
            weather = data["main"]
            temperature = weather["temp"]
            humidity = weather["humidity"]
            description = data["weather"][0]["description"]
            say(f"Weather in {city}:")
            say(f"Temperature: {temperature}°C")
            say(f"Humidity: {humidity}%")
            say(f"Description: {description}")
        except KeyError as e:
            say("Error:", e)
            say("Invalid response format. Please check your API key or city name.")
    else:
        say("City not found.")



def weather_main():
    city = recognize_speech()
    if city:
        get_weather(city)


