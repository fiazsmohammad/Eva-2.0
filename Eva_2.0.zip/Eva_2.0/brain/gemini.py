import google.generativeai as genai

def query_gemini(prompt):
    

    genai.configure(api_key='AIzaSyBzTjBs8RLPUJEaD71Q6KdB0HzDvZwKoZM')  
    model = genai.GenerativeModel(model_name='gemini-pro')

    response = model.generate_content(prompt)
    return response.text


