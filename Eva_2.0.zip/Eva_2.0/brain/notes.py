import speech_recognition as sr
from pollytest import say
import os

def take_note():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        
        say("Say something to take a note")
        
        audio = r.listen(source)

        try:
            note_text = r.recognize_google(audio)
            say("You said:" + note_text)
            save_note(note_text)
        except sr.UnknownValueError:
            say("Sorry, I couldn't understand that.")
            
        except sr.RequestError as e:
            say(f"Error from Speech Recognition; {e}")
            

def save_note(text):
    filename = get_voice_input("Give a filename") + ".txt"
    with open(filename, "w") as f:
        f.write(text)
    say("Note saved!")
    

def read_note():
    filename = get_voice_input("Give a filename") + ".txt"
    if os.path.exists(filename):
        with open(filename, "r") as f:
            contents = f.read()
            say(contents)
             
    else:
        say("File not found.")
        

def delete_note():
    filename = get_voice_input("Give a filename") + ".txt"
    if os.path.exists(filename):
        os.remove(filename)
        say("Note deleted!")
        
    else:
        say("File not found.")
        

def get_voice_input(message):
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print(message)
        say(message)
        
        audio = r.listen(source)

        try:
            return r.recognize_google(audio)
        except sr.UnknownValueError:
            say("Sorry, I couldn't understand that.")
            
            return 
        except sr.RequestError as e:
            say(f"Error from Google Speech Recognition; {e}")
            
            return ""

def main_notes():
    #say("Choose an action: Take note, read note, delete note, or exit")

    
        
        
    choice = get_voice_input("Choose an action: Take note, read note, or delete note").lower()  

    if choice == 'take note':
        take_note()
    elif choice == 'read note':
        read_note()
    elif choice == 'delete note':
        delete_note()
    #elif choice == 'exit':
        #say("exiting notes")
        #break
    else:
        say("Invalid choice.")
            


