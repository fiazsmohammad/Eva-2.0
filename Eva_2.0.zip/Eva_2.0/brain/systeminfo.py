import psutil
import platform
from pollytest import say


def get_ram_usage():
    total_ram = psutil.virtual_memory().total >> 20  
    available_ram = psutil.virtual_memory().available >> 20
    used_ram = total_ram - available_ram
    ram_percent_used = (used_ram / total_ram) * 100

    say(f"Total RAM: {total_ram} MB")
    say(f"Available RAM: {available_ram} MB")
    say(f"Used RAM: {used_ram} MB")
    say(f"RAM Usage: {ram_percent_used:.2f}%")


def get_cpu_speed():
    cpu_freq = psutil.cpu_freq()
    say(f"CPU Max Frequency: {cpu_freq.max:.2f} MHz")
    say(f"CPU Current Frequency: {cpu_freq.current:.2f} MHz")


def get_system_info():
  
    say("System: Windows 11")
    say(f"Processor: {platform.processor()}")
    say("Processor model : AMD Ryzen 7 4800H")
    get_ram_usage()
    get_cpu_speed()




