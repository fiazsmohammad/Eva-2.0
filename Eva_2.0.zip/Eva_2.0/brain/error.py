import sounddevice as sd
import soundfile as sf
import os

welcome_audio_path = r"C:/Fiaz/disk_e/Eva_2.0/Brain/error.mp3"

def play_error():
    if os.path.isfile(welcome_audio_path):
        try:
            data, fs = sf.read(welcome_audio_path)
            sd.play(data, fs)
            sd.wait()  
        except Exception as e:
            pass
    else:
        pass



