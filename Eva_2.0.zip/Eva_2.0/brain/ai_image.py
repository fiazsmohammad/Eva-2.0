import openai 
import requests 
from PIL import Image
from io import BytesIO
import speech_recognition as sr  
from pollytest import say 
import success 

openai.api_key = 

def generate_image(text, size="1024x1024"): 
    res = openai.Image.create( 
        prompt=text, 
        n=1, 
        size=size, 
    ) 
    return res["data"][0]["url"]

def display_image(url):
    response = requests.get(url)
    try:

        if response.status_code == 200:
            if response.headers.get('content-type').startswith('image'):
                success.play_success()
                say("Displaying the generated image")  
                image = Image.open(BytesIO(response.content))
                image.show()
            else:
                say("Error: Invalid image format. Content type:", response.headers.get('content-type'))
        else:
            say("Error: Unable to fetch image. Status code:", response.status_code)

    except requests.exceptions.RequestException as e:  # Catch network-related errors
        say("An error occurred while fetching the image. Please try again later.")
        say(f"Request error: {e}") 

    except (IOError, PIL.UnidentifiedImageError) as e:  # Catch image-related errors
        say("An error occurred while processing the image. Please try again later.")
        say(f"Image processing error: {e}")
        pass