#AIzaSyBzTjBs8RLPUJEaD71Q6KdB0HzDvZwKoZM
import google.generativeai as palm
from pollytest import say

def generate_text(api_key_, model_id, prompt, temperature=1,max_output_tokens=1024, candidate_count=1):

     palm.configure(api_key="AIzaSyBzTjBs8RLPUJEaD71Q6KdB0HzDvZwKoZM")
     completion=palm.generate_text(
        model=model_id,
        prompt=prompt,
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        candidate_count=candidate_count,
     )
     say(completion.result)
model_id="models/text-bison-001"
prompt="crack a joke"
api_key="AIzaSyBzTjBs8RLPUJEaD71Q6KdB0HzDvZwKoZM"
#generate_text(api_key, model_id=model_id,prompt=prompt, candidate_count=3)