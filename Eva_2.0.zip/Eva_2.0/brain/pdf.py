from PyPDF2 import PdfReader
from pollytest import say
import sys
import speech_recognition as sr

def listen_pdf():
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            query = r.recognize_google(audio, language="en-in").lower()
            return query
        except Exception as e:
            
            pass

def read_pdf():
    reader = PdfReader("C:\Fiaz\disk_e\Eva_2.0\Brain\EVAPAPER (2).pdf")
    for page in reader.pages:
        text = page.extract_text()
        lines = text.splitlines() 

        for line in lines:
            say(line)

            say("Do you wish to continue ?")
            command=listen_pdf()
            if command is not None and "stop" in command:
                say("Stopping")
                return  

    say("Finished reading PDF.")


def limit_or_split_text(text, max_chars=1500):
    if len(text) <= max_chars:
        return text  
    else:
        
        chunks = []
        current_chunk = ""
        for word in text.split():
            if len(current_chunk + " " + word) > max_chars:
                chunks.append(current_chunk.strip())
                current_chunk = ""
            current_chunk += " " + word
        chunks.append(current_chunk.strip())  
        return chunks











