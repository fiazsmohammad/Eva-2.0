'''import requests
#3abd2f0d722742199db24278ce072d07
def get_news():
    news_headline = []
    result = requests.get(f"https://newsapi.org/v2/top-headlines?country=in&category=general&apiKey"
                          f"=3abd2f0d722742199db24278ce072d07").json()
    articles = result["articles"]
    for article in articles:
        news_headline.append(article["title"])
    return news_headline[:6]'''

import requests
import speech_recognition as sr
from pollytest import say


API_KEY = "3abd2f0d722742199db24278ce072d07" 

def get_news():
    try:

        news_headline = []
        result = requests.get(f"https://newsapi.org/v2/top-headlines?country=in&category=general&apiKey"
                            f"=3abd2f0d722742199db24278ce072d07").json()
        articles = result["articles"]
        for article in articles:
            news_headline.append(article["title"])
        return news_headline[:15]
    except Exception as e:
        say("Some error occurred. Please try again later!")

def read_news(news_headline):
     
    for i, article in enumerate(news_headline):
        say(article)
        

        
        r = sr.Recognizer()
        with sr.Microphone() as source:
            say("Do you wish to continue ?")
            #print("Say 'continue' to hear the next news, or 'stop' to exit")
            audio = r.listen(source)
            try:
                command = r.recognize_google(audio).lower()
                if command == 'stop':
                    say("stopping")
                    break  
            except sr.UnknownValueError:
                say("Could not understand audio") 

