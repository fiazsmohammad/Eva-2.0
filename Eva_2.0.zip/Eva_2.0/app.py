from flask import Flask, render_template
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_voice_assistant')
def start_voice_assistant_route():
    try:
        subprocess.Popen(['python', 'brain/engine.py'])
        return 'Voice assistant listening mode started', 200
    except Exception as e:
        return f'Error starting voice assistant: {e}', 500

if __name__ == '__main__':
    app.run(debug=True)
